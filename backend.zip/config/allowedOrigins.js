const allowedOrigins = [
    'http://localhost:3000',
    'http://localhost:5173',
    'https://resellersprint.com',
    'https://www.cotektechnologies.com',
    'https://cotektech.com',
    'https://resprint.api.resellersprint.com',
    'http://localhost:3500',
    'https://testweb.rsprint.resellersprint.com'
]

module.exports = allowedOrigins;